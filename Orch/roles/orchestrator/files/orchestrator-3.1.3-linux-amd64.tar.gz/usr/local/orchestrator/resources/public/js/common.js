function Instance(){

}
Instance.createElement = function (instance){
    return $('<div class="instance"><div></div><h3 class="instance-title"></h3><div class="instance-content"></div></div>');
}